<?php get_header();?>
<?php get_footer(); ?>
<?php wp_footer();?>
</body>
</html>